"use strict";
/**
 * X Media Navigator: deterministic helpers. This namespace has no browser-side effects.
 * It is compiled together with content.ts into a single MV3 content script.
 */
var XMN;
(function (XMN) {
    const HANDLE_RE = /^[a-zA-Z0-9_]{1,15}$/;
    const MEDIA_ROUTE_RE = /^\/([^/?#]+)\/media\/?$/;
    const POST_ROUTE_RE = /^\/([^/?#]+)\/status\/(\d+)(?:\/(photo|video)\/(\d+))?\/?$/;
    const HOSTS = new Set(['x.com', 'www.x.com', 'twitter.com', 'www.twitter.com']);
    function mediaProfileFromPath(pathname) {
        const match = MEDIA_ROUTE_RE.exec(pathname);
        if (!match || !HANDLE_RE.test(match[1]))
            return null;
        return match[1].toLowerCase();
    }
    XMN.mediaProfileFromPath = mediaProfileFromPath;
    /**
     * Media tab URL may keep the same pathname when the Photos/Videos dropdown changes.
     * An absent filter is NOT assumed to mean video: record it independently.
     * Unrelated query params are deliberately ignored.
     */
    function mediaTimelineKey(pathname, search) {
        const profile = mediaProfileFromPath(pathname);
        if (!profile)
            return null;
        const filters = new URLSearchParams(search).getAll('filter').map((value) => value.trim().toLowerCase());
        const mode = filters.length === 0 ? 'default'
            : filters.length === 1 ? (filters[0] || 'empty') : `multi:${filters.join(',')}`;
        return `${profile}|${encodeURIComponent(mode)}`;
    }
    XMN.mediaTimelineKey = mediaTimelineKey;
    /** Only a complete 4-photo set proves album completion without a gallery counter. */
    function completeFourPhotoSet(indexes) {
        return indexes.size === 4 && [1, 2, 3, 4].every((index) => indexes.has(index));
    }
    XMN.completeFourPhotoSet = completeFourPhotoSet;
    /** Parse only explicit media counters; Japanese "N枚中M枚目" lists total first. */
    function parseGalleryCounter(label) {
        const text = label.trim().normalize('NFKC');
        const japanese = /^(?:全\s*)?(\d+)\s*枚中\s*(\d+)\s*枚目$/.exec(text);
        const standard = /^(?:(?:image|photo|picture|画像|写真)\s*)?(\d+)\s*(?:\/|of)\s*(\d+)\s*(?:枚目|枚)?$/i.exec(text);
        if (!japanese && !standard)
            return null;
        const current = Number(japanese ? japanese[2] : standard[1]);
        const total = Number(japanese ? japanese[1] : standard[2]);
        return Number.isInteger(current) && Number.isInteger(total) && current >= 1 &&
            total >= current && total <= 4 ? { current, total } : null;
    }
    XMN.parseGalleryCounter = parseGalleryCounter;
    function profileStatusFromPath(pathname, profile) {
        const match = POST_ROUTE_RE.exec(pathname);
        return !!match && match[1].toLowerCase() === profile.toLowerCase();
    }
    XMN.profileStatusFromPath = profileStatusFromPath;
    /**
     * Resolve only links belonging to the active profile. Strip query/fragment to make
     * the key stable across tracking parameters; include photo/video position.
     */
    function mediaRefFromHref(href, profile) {
        if (!HANDLE_RE.test(profile))
            return null;
        let url;
        try {
            url = new URL(href, 'https://x.com');
        }
        catch {
            return null;
        }
        if (!HOSTS.has(url.hostname.toLowerCase()) || !['https:', 'http:'].includes(url.protocol))
            return null;
        const match = POST_ROUTE_RE.exec(url.pathname);
        if (!match || match[1].toLowerCase() !== profile.toLowerCase())
            return null;
        const kind = match[3] ?? null;
        const mediaIndex = match[4] === undefined ? null : Number(match[4]);
        if (mediaIndex !== null && (!Number.isSafeInteger(mediaIndex) || mediaIndex < 1 || mediaIndex > 100))
            return null;
        const key = `${match[2]}:${kind ?? 'post'}:${mediaIndex ?? 0}`;
        return { key, statusId: match[2], profile: profile.toLowerCase(), kind, mediaIndex, href: url.pathname };
    }
    XMN.mediaRefFromHref = mediaRefFromHref;
    function adjacentIndex(index, size, direction) {
        if (!Number.isSafeInteger(index) || index < 0 || index >= size)
            return null;
        const next = index + direction;
        return next < 0 || next >= size ? null : next;
    }
    XMN.adjacentIndex = adjacentIndex;
    function findCurrentIndex(items, pathname, profile) {
        const current = mediaRefFromHref(pathname, profile);
        if (!current)
            return null;
        const exact = items.findIndex((item) => item.key === current.key);
        if (exact >= 0)
            return exact;
        // URLs without /photo/N can only be resolved safely when the status has one item.
        const sameStatus = items.map((item, i) => ({ item, i })).filter(({ item }) => item.statusId === current.statusId);
        if (sameStatus.length === 1)
            return sameStatus[0].i;
        return null;
    }
    XMN.findCurrentIndex = findCurrentIndex;
    /** A bare arrow may cross posts ONLY at a verified photo boundary. */
    function postShortcutDirection(event) {
        if (event.shiftKey || event.altKey || event.ctrlKey || event.metaKey || event.repeat || event.isComposing)
            return null;
        if (event.key === 'ArrowRight')
            return 1;
        if (event.key === 'ArrowLeft')
            return -1;
        return null;
    }
    XMN.postShortcutDirection = postShortcutDirection;
    function galleryBoundaryDirection(event, current, photoCount, nativeNextAvailable = false, nativePreviousAvailable = false) {
        const direction = postShortcutDirection(event);
        if (!direction || current?.kind !== 'photo' || current.mediaIndex === null)
            return null;
        if (direction === -1)
            return current.mediaIndex === 1 && !nativePreviousAvailable ? -1 : null;
        if (nativeNextAvailable)
            return null;
        return photoCount !== null && photoCount >= 1 && current.mediaIndex === photoCount ? 1 : null;
    }
    XMN.galleryBoundaryDirection = galleryBoundaryDirection;
    /**
     * Move across the CONTIGUOUS status group at the active position, not the last
     * occurrence of that ID anywhere in the timeline. A repeated status can appear
     * again after another post; skipping every occurrence would skip entire posts.
     */
    function adjacentPostIndex(items, currentStatusId, direction, activePosition) {
        const anchored = activePosition !== undefined && Number.isSafeInteger(activePosition) &&
            activePosition >= 0 && activePosition < items.length &&
            items[activePosition].statusId === currentStatusId;
        let start = anchored ? activePosition : -1;
        if (!anchored) {
            for (let i = 0; i < items.length; i++) {
                if (items[i].statusId !== currentStatusId)
                    continue;
                start = i;
                if (direction === 1)
                    break;
            }
        }
        if (start < 0)
            return null;
        for (let i = start + direction; i >= 0 && i < items.length; i += direction) {
            if (items[i].statusId !== currentStatusId)
                return i;
        }
        return null;
    }
    XMN.adjacentPostIndex = adjacentPostIndex;
    /** Only rewrite genuine X image CDN thumbnails. No arbitrary URL/network access. */
    function preloadImageUrl(src) {
        let url;
        try {
            url = new URL(src);
        }
        catch {
            return null;
        }
        if (url.protocol !== 'https:' || url.hostname !== 'pbs.twimg.com' ||
            !/^\/media\/[A-Za-z0-9_-]+$/.test(url.pathname) ||
            !/^(jpg|jpeg|png|webp)$/i.test(url.searchParams.get('format') ?? '') ||
            !url.searchParams.has('name'))
            return null;
        url.searchParams.set('name', 'large');
        url.hash = '';
        return url.toString();
    }
    XMN.preloadImageUrl = preloadImageUrl;
})(XMN || (XMN = {}));
/// <reference path="./core.ts" />
/**
 * MV3 content-script controller. No page-world monkeypatches or network requests.
 * Bare arrow keys stay under X's control until a CONFIRMED gallery boundary.
 * Only then is a post-to-post navigation attempted.
 */
var XMN;
(function (XMN) {
    const VIEWER_SELECTOR = '[data-testid="swipe-to-dismiss"]';
    const TILE_SELECTOR = 'li[role="listitem"]';
    const NATIVE_NEXT = /^(next(?: (?:photo|image|media))?|次の(?:画像|写真|メディア)(?:へ)?|次へ)$/i;
    const NATIVE_PREVIOUS = /^(prev(?:ious)?(?: (?:photo|image|media))?|前の(?:画像|写真|メディア)(?:へ)?|前へ)$/i;
    const CLOSE_SELECTOR = [
        'button[data-testid="app-bar-close"]',
        '[role="button"][data-testid="app-bar-close"]',
        'button[aria-label="閉じる"]',
        '[role="button"][aria-label="閉じる"]',
        'button[aria-label="Close"]',
        '[role="button"][aria-label="Close"]',
    ].join(',');
    function pause(ms) {
        return new Promise((resolve) => window.setTimeout(resolve, ms));
    }
    function mediaColumn() {
        return document.querySelector('main [data-testid="primaryColumn"]') ?? document.querySelector('main');
    }
    function isEditingTarget(target) {
        if (!(target instanceof Element))
            return false;
        return !!target.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"]), [role="textbox"], [role="combobox"], [role="slider"], [role="spinbutton"], video');
    }
    function usableTileLink(tile, profile) {
        const links = Array.from(tile.querySelectorAll('a[href]'));
        const possibilities = links
            // A quoted post can contain its own media links. They are not the
            // originating profile's media tile, even if the handle matches.
            .filter((link) => !link.closest('[data-testid="quoteTweet"]'))
            .map((link) => ({ link, ref: XMN.mediaRefFromHref(link.getAttribute('href') ?? '', profile) }))
            .filter((candidate) => candidate.ref !== null);
        const hasThumbnail = !!tile.querySelector('img, video');
        // Prefer the link actually wrapping the thumbnail, not an unrelated
        // reply/permalink. Ambiguous owners are safer to leave unnumbered.
        const owned = possibilities.filter(({ link }) => !!link.querySelector('img, video'));
        if (owned.length === 1)
            return owned[0];
        if (owned.length > 1)
            return null;
        if (new Set(possibilities.map(({ ref }) => ref.statusId)).size > 1)
            return null;
        const explicit = possibilities.find(({ ref }) => ref.kind !== null);
        // X can leave a not-yet-loaded image placeholder in the grid. Preserve
        // one explicit /photo/N or /video/N link even before the img appears.
        if (!hasThumbnail)
            return possibilities.length === 1 ? explicit ?? null : null;
        // In older grids, the image sits outside its link. A single owner is still safe.
        return explicit ?? possibilities[0] ?? null;
    }
    /** Maintain a stable ordered list of media refs, never cached DOM nodes. */
    class Controller {
        constructor() {
            this.originProfile = null;
            this.originTimeline = null;
            this.pendingGrid = null;
            this.refs = [];
            this.indexes = new Map();
            this.imageSources = new Map();
            this.prefetched = new Map();
            this.handoff = null;
            this.preloadTimer = null;
            this.preloadForPath = '';
            this.pendingRightConfirmation = null;
            this.nativeAdvancedPost = null;
            this.rightProbeTimer = null;
            this.viewer = null;
            this.viewObserver = null;
            this.listObserver = null;
            this.observedColumn = null;
            this.lastPath = '';
            this.scanTimer = null;
            this.navigationBusy = false;
            this.navGeneration = 0;
            // Observe actual user keyboard input only when the viewer belongs to a media-tab session.
            document.addEventListener('keydown', (event) => this.onKeyDown(event), true);
            this.refreshId = window.setInterval(() => this.tick(), 450);
            this.tick();
        }
        resetSession() {
            this.navGeneration++;
            this.navigationBusy = false;
            this.pendingGrid = null;
            this.refs = [];
            this.indexes.clear();
            this.imageSources.clear();
            this.clearVisualHandoff();
            this.prefetched.clear();
            this.preloadForPath = '';
            this.pendingRightConfirmation = null;
            this.nativeAdvancedPost = null;
            if (this.rightProbeTimer !== null)
                window.clearTimeout(this.rightProbeTimer);
            this.rightProbeTimer = null;
            if (this.preloadTimer !== null)
                window.clearTimeout(this.preloadTimer);
            this.preloadTimer = null;
            this.removeViewerUI();
            this.stopListObserver();
            document.querySelectorAll('.xmn-tile-badge').forEach((element) => element.remove());
            document.querySelectorAll('.xmn-numbered-tile').forEach((element) => element.classList.remove('xmn-numbered-tile'));
        }
        stopListObserver() {
            this.listObserver?.disconnect();
            this.listObserver = null;
            this.observedColumn = null;
            if (this.scanTimer !== null)
                window.clearTimeout(this.scanTimer);
            this.scanTimer = null;
        }
        tick() {
            const path = window.location.pathname;
            const atMedia = XMN.mediaProfileFromPath(path);
            const timeline = XMN.mediaTimelineKey(path, window.location.search);
            if (atMedia && timeline) {
                let scanRequired = false;
                if (this.originProfile !== atMedia) {
                    this.resetSession();
                    this.originProfile = atMedia;
                    this.originTimeline = timeline;
                    scanRequired = true;
                }
                else if (this.originTimeline !== timeline) {
                    // A modal close initiated by this extension can temporarily drop
                    // ?filter=photo. Keep the original session until navigate() checks
                    // the actual target. Do not clear refs midway through the operation.
                    if (this.navigationBusy)
                        return;
                    // The URL can change before X paints the new filter results. Never collect
                    // stale photos into the new video timeline (or vice versa).
                    const snapshot = this.captureGrid();
                    this.resetSession();
                    this.originProfile = atMedia;
                    this.originTimeline = timeline;
                    this.pendingGrid = snapshot;
                }
                const observerAdded = this.ensureListObserver();
                if (this.pendingGrid && this.hasGridTurnedOver(this.pendingGrid)) {
                    this.pendingGrid = null;
                    scanRequired = true;
                }
                // The observer handles subsequent DOM changes. Avoid O(N) scanning of a
                // long media timeline every 450ms when nothing has changed.
                if (!this.pendingGrid && (scanRequired || observerAdded))
                    this.scanTiles();
            }
            else if (!this.originProfile || !XMN.profileStatusFromPath(path, this.originProfile)) {
                if (this.originProfile !== null) {
                    this.resetSession();
                    this.originProfile = null;
                    this.originTimeline = null;
                }
            }
            else {
                // The timeline is a retained DOM tree beneath the modal. Do NOT index the
                // status-page recommendations as though they were the originating media tab.
                this.stopListObserver();
            }
            if (path !== this.lastPath) {
                // Track proven native photo changes even if the next key is pressed
                // before the delayed fallback probe completes.
                if (this.originProfile) {
                    const previous = XMN.mediaRefFromHref(this.lastPath, this.originProfile);
                    const displayed = XMN.mediaRefFromHref(path, this.originProfile);
                    if (previous?.kind === 'photo' && displayed?.kind === 'photo' &&
                        previous.statusId === displayed.statusId &&
                        previous.mediaIndex !== displayed.mediaIndex) {
                        this.nativeAdvancedPost = displayed.statusId;
                    }
                }
                this.pendingRightConfirmation = null;
                this.lastPath = path;
            }
            const viewer = this.originProfile && XMN.profileStatusFromPath(path, this.originProfile)
                ? document.querySelector(VIEWER_SELECTOR) : null;
            if (viewer && this.originProfile) {
                this.syncViewer(viewer);
            }
            else {
                this.removeViewerUI();
            }
        }
        /** First few anchors and DOM nodes distinguish X's data swap from our badge cleanup. */
        captureGrid() {
            const column = mediaColumn();
            const firstTiles = column ? Array.from(column.querySelectorAll(TILE_SELECTOR)).slice(0, 8) : [];
            const firstKeys = firstTiles.map((tile) => {
                const link = this.originProfile ? usableTileLink(tile, this.originProfile) : null;
                return link?.ref.key ?? '';
            });
            return { column, firstTiles, firstKeys };
        }
        hasGridTurnedOver(previous) {
            const current = this.captureGrid();
            if (current.firstTiles.length === 0)
                return false;
            // Waiting for X's actual list replacement is safer than a fixed delay.
            if (current.column !== previous.column)
                return true;
            const replaced = current.firstTiles.some((tile, index) => tile !== previous.firstTiles[index]);
            const keysChanged = current.firstKeys.some((key, index) => key !== previous.firstKeys[index]);
            return replaced || keysChanged;
        }
        ensureListObserver() {
            const column = mediaColumn();
            if (!column || column === this.observedColumn)
                return false;
            this.stopListObserver();
            this.observedColumn = column;
            this.listObserver = new MutationObserver(() => {
                if (this.scanTimer !== null)
                    return;
                this.scanTimer = window.setTimeout(() => {
                    this.scanTimer = null;
                    if (XMN.mediaProfileFromPath(window.location.pathname) === this.originProfile) {
                        if (this.pendingGrid && this.hasGridTurnedOver(this.pendingGrid))
                            this.pendingGrid = null;
                        if (!this.pendingGrid)
                            this.scanTiles();
                    }
                }, 100);
            });
            this.listObserver.observe(column, { childList: true, subtree: true });
            return true;
        }
        scanTiles() {
            if (!this.originProfile || this.pendingGrid ||
                XMN.mediaProfileFromPath(window.location.pathname) !== this.originProfile)
                return;
            const root = mediaColumn();
            if (!root)
                return;
            for (const tile of Array.from(root.querySelectorAll(TILE_SELECTOR))) {
                const found = usableTileLink(tile, this.originProfile);
                if (!found)
                    continue;
                const { ref } = found;
                // Capture only CDN image locations from the already-rendered media tiles.
                const ownedImage = found.link.querySelector('img[src]');
                const allImages = tile.querySelectorAll('img[src]');
                const thumbnail = ownedImage ?? (allImages.length === 1 ? allImages[0] : null);
                const imageUrl = thumbnail ? XMN.preloadImageUrl(thumbnail.currentSrc || thumbnail.src || '') : null;
                if (imageUrl) {
                    // Keep only nearby/recent thumbnail URLs in memory during long timelines.
                    this.imageSources.delete(ref.key);
                    this.imageSources.set(ref.key, imageUrl);
                    while (this.imageSources.size > 128) {
                        const oldest = this.imageSources.keys().next().value;
                        if (oldest === undefined)
                            break;
                        this.imageSources.delete(oldest);
                    }
                }
                let index = this.indexes.get(ref.key);
                if (index === undefined) {
                    index = this.refs.length;
                    this.indexes.set(ref.key, index);
                    this.refs.push(ref);
                }
                else {
                    // Refresh references by value. Old DOM nodes are never persisted.
                    this.refs[index] = ref;
                }
                let badge = tile.querySelector(':scope > .xmn-tile-badge');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'xmn-tile-badge';
                    badge.setAttribute('aria-hidden', 'true');
                    tile.classList.add('xmn-numbered-tile');
                    tile.appendChild(badge);
                }
                const label = String(index + 1);
                if (badge.textContent !== label)
                    badge.textContent = label;
            }
        }
        removeViewerUI() {
            this.viewObserver?.disconnect();
            this.viewObserver = null;
            this.pendingRightConfirmation = null;
            if (this.rightProbeTimer !== null)
                window.clearTimeout(this.rightProbeTimer);
            this.rightProbeTimer = null;
            if (this.viewer) {
                this.viewer.querySelectorAll('.xmn-nav-button, .xmn-status').forEach((element) => element.remove());
                this.viewer = null;
            }
        }
        syncViewer(viewer) {
            if (viewer !== this.viewer) {
                this.removeViewerUI();
                this.viewer = viewer;
                this.viewObserver = new MutationObserver(() => {
                    // X may replace viewer children during /photo/N transitions.
                    if (this.viewer?.isConnected)
                        this.ensureViewerButtons();
                });
                this.viewObserver.observe(viewer, { childList: true, subtree: true });
            }
            this.ensureViewerButtons();
            this.finishVisualHandoff(viewer);
        }
        ensureViewerButtons() {
            const viewer = this.viewer;
            if (!viewer || !viewer.isConnected)
                return;
            for (const [direction, className, text, label] of [
                [-1, 'xmn-prev', '◀', '前の投稿へ（最初の画像では←でも移動）'],
                [1, 'xmn-next', '▶', '次の投稿へ（最後の画像では→でも移動）'],
            ]) {
                let button = viewer.querySelector(`.${className}`);
                if (!button) {
                    button = document.createElement('button');
                    button.type = 'button';
                    button.className = `xmn-nav-button ${className}`;
                    button.textContent = text;
                    button.title = label;
                    button.setAttribute('aria-label', label);
                    button.addEventListener('click', (event) => {
                        event.preventDefault();
                        event.stopPropagation();
                        void this.navigate(direction);
                    });
                    viewer.appendChild(button);
                }
            }
            let status = viewer.querySelector('.xmn-status');
            if (!status) {
                status = document.createElement('div');
                status.className = 'xmn-status';
                status.setAttribute('aria-live', 'polite');
                viewer.appendChild(status);
            }
            this.updateViewerState();
            this.schedulePreload();
        }
        activeIndex() {
            if (!this.originProfile)
                return null;
            const exact = XMN.findCurrentIndex(this.refs, window.location.pathname, this.originProfile);
            if (exact !== null)
                return exact;
            // A media tab may offer only one link for a post with several photos.
            const current = XMN.mediaRefFromHref(window.location.pathname, this.originProfile);
            const matches = current ? this.refs.map((ref, i) => ({ ref, i }))
                .filter(({ ref }) => ref.statusId === current.statusId) : [];
            return matches.length ? matches[0].i : null;
        }
        updateViewerState() {
            const viewer = this.viewer;
            if (!viewer)
                return;
            const current = this.activeIndex();
            const prev = viewer.querySelector('.xmn-prev');
            const next = viewer.querySelector('.xmn-next');
            const currentRef = current !== null ? this.refs[current] : null;
            if (prev)
                prev.disabled = this.navigationBusy || !currentRef || XMN.adjacentPostIndex(this.refs, currentRef.statusId, -1, current ?? undefined) === null;
            // At the last known post clicking the next button may load more media.
            if (next)
                next.disabled = this.navigationBusy || !currentRef;
            const indicator = viewer.querySelector('.xmn-status');
            if (indicator) {
                const statuses = Array.from(new Set(this.refs.map((ref) => ref.statusId)));
                const index = currentRef ? statuses.indexOf(currentRef.statusId) : -1;
                const label = index < 0 ? '投稿の位置を確認中' : `投稿 ${index + 1} / ${statuses.length}`;
                if (indicator.textContent !== label)
                    indicator.textContent = label;
            }
        }
        /**
         * A positive gallery-size hint from the original post's media thumbnails.
         * Do not count media from unrelated replies or quoted posts.
         * If X changes its DOM or count is uncertain, do not take over ArrowRight.
         */
        photoCount(viewer, statusId) {
            const root = viewer.closest('[role="dialog"]') ?? viewer.parentElement;
            const profile = this.originProfile;
            if (!root || !profile)
                return null;
            const displayed = XMN.mediaRefFromHref(window.location.pathname, profile);
            // X can render a gallery counter. Confirm it belongs to the displayed photo,
            // rather than matching a number in an unrelated reply or recommended post.
            if (displayed?.kind === 'photo' && displayed.statusId === statusId) {
                for (const node of viewer.querySelectorAll('[aria-label], [title]')) {
                    if (node.closest('.xmn-nav-button, .xmn-status'))
                        continue;
                    for (const label of [node.getAttribute('aria-label'), node.getAttribute('title')]) {
                        const count = label && XMN.parseGalleryCounter(label);
                        if (count && count.current === displayed.mediaIndex)
                            return count.total;
                    }
                }
            }
            // Official X rules cap photos at four; seeing all four distinct photo URLs
            // is therefore complete evidence. One, two, or three visible thumbnails
            // are NOT proof that the post contains no additional hidden photos.
            const indexes = new Set();
            for (const article of root.querySelectorAll('article[data-testid="tweet"]')) {
                for (const link of article.querySelectorAll('a[href*="/photo/"]')) {
                    const ref = XMN.mediaRefFromHref(link.getAttribute('href') ?? '', profile);
                    if (ref?.statusId === statusId && ref.kind === 'photo' && ref.mediaIndex !== null)
                        indexes.add(ref.mediaIndex);
                }
            }
            if (XMN.completeFourPhotoSet(indexes))
                return 4;
            // X may render the COMPLETE original post's photo grid with 1–3 photos,
            // without providing an explicit gallery counter in the fullscreen modal.
            // Require one uniquely indexed link per owned tweetPhoto tile. Do not
            // infer a count from arbitrary links or from one visible gallery image.
            for (const article of root.querySelectorAll('article[data-testid="tweet"]')) {
                if (article.closest('[data-testid="quoteTweet"]'))
                    continue;
                const photoTiles = Array.from(article.querySelectorAll('[data-testid="tweetPhoto"]'))
                    .filter((tile) => !tile.closest('[data-testid="quoteTweet"]'));
                if (photoTiles.length < 1 || photoTiles.length > 3)
                    continue;
                const ownedIndexes = [];
                let valid = true;
                for (const tile of photoTiles) {
                    const found = Array.from(tile.querySelectorAll('a[href*="/photo/"]'))
                        .map((link) => XMN.mediaRefFromHref(link.getAttribute('href') ?? '', profile))
                        .filter((ref) => ref !== null && ref.kind === 'photo' && ref.statusId === statusId);
                    if (found.length !== 1 || found[0].mediaIndex === null) {
                        valid = false;
                        break;
                    }
                    ownedIndexes.push(found[0].mediaIndex);
                }
                const seen = new Set(ownedIndexes);
                if (valid && seen.size === photoTiles.length &&
                    Array.from({ length: photoTiles.length }, (_, index) => index + 1).every((index) => seen.has(index)) &&
                    displayed?.statusId === statusId && displayed?.kind === 'photo' &&
                    displayed.mediaIndex !== null && displayed.mediaIndex <= photoTiles.length) {
                    return photoTiles.length;
                }
            }
            return null;
        }
        nativeGalleryArrowAvailable(viewer, direction) {
            const root = viewer.closest('[role="dialog"]') ?? viewer;
            const pattern = direction === 1 ? NATIVE_NEXT : NATIVE_PREVIOUS;
            for (const button of root.querySelectorAll('[aria-label], [title]')) {
                if (button.closest('.xmn-nav-button'))
                    continue;
                const label = (button.getAttribute('aria-label') || button.getAttribute('title') || '').trim();
                if (pattern.test(label) && button.getAttribute('aria-disabled') !== 'true' &&
                    !(button instanceof HTMLButtonElement && button.disabled))
                    return true;
            }
            return false;
        }
        onKeyDown(event) {
            if (!this.viewer?.isConnected || !this.originProfile ||
                isEditingTarget(event.target) || this.navigationBusy)
                return;
            const currentIndex = this.activeIndex();
            if (currentIndex === null)
                return;
            const current = XMN.mediaRefFromHref(window.location.pathname, this.originProfile);
            const photoCount = current ? this.photoCount(this.viewer, current.statusId) : null;
            const nativeNext = this.nativeGalleryArrowAvailable(this.viewer, 1);
            const direction = XMN.galleryBoundaryDirection(event, current, photoCount, nativeNext, this.nativeGalleryArrowAvailable(this.viewer, -1));
            if (direction === null) {
                // X may not expose a gallery counter. Give its own ArrowRight handler
                // first chance to change photos, then offer a non-skipping fallback.
                if (current && current.kind === 'photo' && event.key === 'ArrowRight' &&
                    XMN.postShortcutDirection(event) === 1 && !nativeNext) {
                    this.handleUnknownRightBoundary(event, current);
                }
                return;
            }
            if (direction === -1 && current && XMN.adjacentPostIndex(this.refs, current.statusId, -1, currentIndex) === null)
                return;
            this.pendingRightConfirmation = null;
            event.preventDefault();
            event.stopImmediatePropagation();
            void this.navigate(direction);
        }
        /** Snapshot only the displayed photo, never an unrelated reply image. */
        currentPhotoSignature() {
            const viewer = this.viewer;
            if (!viewer)
                return null;
            const image = viewer.querySelector('img[src]');
            return image?.currentSrc || image?.src || null;
        }
        /**
         * Last-photo fallback when X provides no total count / reliable arrow label.
         * A native transition is always allowed first. A known working native gallery
         * can advance on its first stalled press; otherwise require explicit repeat
         * confirmation to avoid skipping an unseen image in an unknown-length post.
         */
        handleUnknownRightBoundary(event, current) {
            if (!this.viewer || this.navigationBusy)
                return;
            const path = window.location.pathname;
            const signature = this.currentPhotoSignature();
            const pending = this.pendingRightConfirmation;
            if (pending && pending.path === path && pending.signature === signature &&
                Date.now() < pending.expiresAt) {
                this.pendingRightConfirmation = null;
                if (this.rightProbeTimer !== null)
                    window.clearTimeout(this.rightProbeTimer);
                this.rightProbeTimer = null;
                event.preventDefault();
                event.stopImmediatePropagation();
                void this.navigate(1);
                return;
            }
            this.pendingRightConfirmation = null;
            if (this.rightProbeTimer !== null)
                window.clearTimeout(this.rightProbeTimer);
            const generation = this.navGeneration;
            const viewer = this.viewer;
            this.rightProbeTimer = window.setTimeout(() => {
                this.rightProbeTimer = null;
                if (generation !== this.navGeneration || viewer !== this.viewer ||
                    !viewer.isConnected || this.navigationBusy)
                    return;
                const after = this.originProfile ? XMN.mediaRefFromHref(window.location.pathname, this.originProfile) : null;
                if (!after || after.statusId !== current.statusId)
                    return;
                if (window.location.pathname !== path || this.currentPhotoSignature() !== signature) {
                    if (after.mediaIndex !== null && current.mediaIndex !== null &&
                        after.mediaIndex !== current.mediaIndex)
                        this.nativeAdvancedPost = current.statusId;
                    return;
                }
                if (this.nativeGalleryArrowAvailable(viewer, 1))
                    return;
                if (current.mediaIndex !== null && current.mediaIndex > 1 &&
                    this.nativeAdvancedPost === current.statusId) {
                    void this.navigate(1);
                    return;
                }
                this.pendingRightConfirmation = {
                    path, signature, expiresAt: Date.now() + 2600,
                };
                this.toast('画像枚数を確認できません。もう一度→で次の投稿へ');
            }, 850);
        }
        schedulePreload() {
            if (!this.originProfile || !this.viewer || document.hidden)
                return;
            const key = `${this.originTimeline ?? ''}|${window.location.pathname}|${this.refs.length}`;
            if (key === this.preloadForPath)
                return;
            this.preloadForPath = key;
            if (this.preloadTimer !== null)
                window.clearTimeout(this.preloadTimer);
            this.preloadTimer = window.setTimeout(() => {
                this.preloadTimer = null;
                this.preloadAdjacentImages();
            }, 350);
        }
        preloadAdjacentImages() {
            if (!this.viewer?.isConnected || !this.originProfile || document.hidden ||
                (typeof navigator !== 'undefined' && navigator.onLine === false))
                return;
            const connection = navigator.connection;
            if (connection?.saveData || /^(slow-2g|2g)$/.test(connection?.effectiveType ?? ''))
                return;
            const index = this.activeIndex();
            const current = XMN.mediaRefFromHref(window.location.pathname, this.originProfile);
            if (index === null || !current)
                return;
            const targets = [];
            // Preheat the next photo AND the next POST while the first image is still
            // displayed. This avoids starting the post's CDN request only at the end.
            const forward = this.refs[index + 1];
            if (forward?.statusId === current.statusId && forward.kind === 'photo' &&
                forward.mediaIndex !== null && current.mediaIndex !== null &&
                forward.mediaIndex > current.mediaIndex)
                targets.push(forward);
            const nextPost = XMN.adjacentPostIndex(this.refs, current.statusId, 1, index);
            if (nextPost !== null)
                targets.push(this.refs[nextPost]);
            // Use remaining capacity for backwards navigation.
            if (targets.length < 2) {
                const back = this.refs[index - 1];
                if (back?.statusId === current.statusId && back.kind === 'photo' &&
                    back.mediaIndex !== null && current.mediaIndex !== null &&
                    back.mediaIndex < current.mediaIndex)
                    targets.push(back);
                else {
                    const previousPost = XMN.adjacentPostIndex(this.refs, current.statusId, -1, index);
                    if (previousPost !== null)
                        targets.push(this.refs[previousPost]);
                }
            }
            const urls = targets.map((ref) => this.imageSources.get(ref.key)).filter((url) => !!url);
            const unique = [...new Set(urls)].slice(0, 2);
            for (const [url] of this.prefetched) {
                if (!unique.includes(url))
                    this.prefetched.delete(url);
            }
            for (const url of unique) {
                if (this.prefetched.has(url))
                    continue;
                const image = new Image();
                const record = { image, ready: false };
                image.decoding = 'async';
                image.fetchPriority = 'low';
                // A failed URL must not be retried forever while the viewer remains open.
                image.onerror = () => {
                    if (this.prefetched.get(url) === record)
                        this.prefetched.delete(url);
                };
                this.prefetched.set(url, record);
                image.src = url;
                if (typeof image.decode === 'function') {
                    // decode() establishes readiness to paint without a blank frame.
                    void image.decode().then(() => {
                        if (this.prefetched.get(url) === record && image.naturalWidth > 0)
                            record.ready = true;
                    }).catch(() => {
                        if (this.prefetched.get(url) === record)
                            this.prefetched.delete(url);
                    });
                }
            }
        }
        /**
         * Visual-only handoff while X closes and reopens its SPA photo viewer.
         * X still owns the URL, history and modal; this only paints an already
         * decoded, low-priority CDN image for <= 1.8s. No extra network request.
         */
        beginVisualHandoff(target) {
            if (target.kind !== 'photo' || this.handoff || !this.originProfile || document.hidden)
                return false;
            if (typeof window.matchMedia === 'function' &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches)
                return false;
            const url = this.imageSources?.get(target.key);
            const record = url ? this.prefetched?.get(url) : undefined;
            if (!url || XMN.preloadImageUrl(url) !== url || !record?.ready || record.image.naturalWidth < 1)
                return false;
            let host = null;
            try {
                host = document.createElement('div');
                host.className = 'xmn-visual-handoff';
                host.setAttribute('aria-hidden', 'true');
                record.image.classList.add('xmn-handoff-image');
                host.appendChild(record.image);
                document.body.appendChild(host);
                const timeout = window.setTimeout(() => this.clearVisualHandoff(), 1800);
                this.handoff = {
                    host,
                    targetStatus: target.statusId,
                    targetMediaIndex: target.mediaIndex,
                    timeout,
                    generation: this.navGeneration,
                    revealTimer: null,
                };
                return true;
            }
            catch {
                host?.remove();
                return false; // Handoff is optional; never interrupt native SPA navigation.
            }
        }
        finishVisualHandoff(viewer) {
            const handoff = this.handoff;
            if (!handoff || handoff.revealTimer !== null || !viewer.isConnected ||
                handoff.generation !== this.navGeneration || !this.originProfile)
                return;
            const shown = XMN.mediaRefFromHref(window.location.pathname, this.originProfile);
            if (!shown || shown.statusId !== handoff.targetStatus ||
                (handoff.targetMediaIndex !== null && shown.mediaIndex !== null &&
                    handoff.targetMediaIndex !== shown.mediaIndex))
                return;
            // Give X a frame to paint the newly opened viewer before removing the
            // handoff image. The failsafe timer still expires if X never renders it.
            handoff.revealTimer = window.setTimeout(() => {
                if (this.handoff === handoff)
                    this.clearVisualHandoff();
            }, 130);
        }
        clearVisualHandoff() {
            const handoff = this.handoff;
            if (!handoff)
                return;
            this.handoff = null;
            window.clearTimeout(handoff.timeout);
            if (handoff.revealTimer !== null)
                window.clearTimeout(handoff.revealTimer);
            handoff.host.remove();
        }
        findCloseButton(viewer) {
            const dialog = viewer.closest('[role="dialog"]');
            const local = dialog?.querySelector(CLOSE_SELECTOR);
            if (local)
                return local;
            // Do not click an unrelated button if the global query is ambiguous.
            const matches = document.querySelectorAll(CLOSE_SELECTOR);
            return matches.length === 1 ? matches[0] : null;
        }
        findLiveLink(ref) {
            if (!this.originProfile)
                return null;
            const column = mediaColumn();
            if (!column)
                return null;
            for (const tile of column.querySelectorAll(TILE_SELECTOR)) {
                const found = usableTileLink(tile, this.originProfile);
                if (found?.ref.key === ref.key && found.link.isConnected)
                    return found.link;
            }
            return null;
        }
        toast(message) {
            let element = document.querySelector('.xmn-toast');
            if (!element) {
                element = document.createElement('div');
                element.className = 'xmn-toast';
                element.setAttribute('role', 'status');
                document.body.appendChild(element);
            }
            element.textContent = message;
            window.setTimeout(() => {
                if (element?.textContent === message)
                    element.remove();
            }, 2800);
        }
        async waitForViewerToClose(viewer) {
            for (let i = 0; i < 12; i++) {
                if (!viewer.isConnected || !document.querySelector(VIEWER_SELECTOR))
                    return true;
                await pause(125);
            }
            return !viewer.isConnected;
        }
        /** Wait for a DIFFERENT post; new images of the current post are not enough. */
        async loadNextPost(statusId, generation, fromIndex) {
            for (let attempt = 0; attempt < 20; attempt++) {
                if (generation !== this.navGeneration)
                    return null;
                this.scanTiles();
                const nextIndex = XMN.adjacentPostIndex(this.refs, statusId, 1, fromIndex);
                if (nextIndex !== null)
                    return this.refs[nextIndex];
                // Prefer scrolling the final *visible media tile*. scrollIntoView also
                // reaches nested scroll containers, unlike window.scrollTo alone.
                if (attempt % 3 === 0) {
                    const tiles = mediaColumn()?.querySelectorAll(TILE_SELECTOR);
                    const last = tiles?.length ? tiles[tiles.length - 1] : null;
                    if (last && typeof last.scrollIntoView === 'function') {
                        last.scrollIntoView({ block: 'end', behavior: 'auto' });
                    }
                    // Some timelines listen for window scroll instead of item visibility.
                    // Keep the original scroll fallback even when the nested scroll succeeds.
                    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'auto' });
                }
                await pause(200);
            }
            this.scanTiles();
            const nextIndex = XMN.adjacentPostIndex(this.refs, statusId, 1, fromIndex);
            return nextIndex === null ? null : this.refs[nextIndex];
        }
        async navigate(direction) {
            const currentIndex = this.activeIndex();
            const oldViewer = this.viewer;
            if (this.navigationBusy || currentIndex === null || !oldViewer || !this.originProfile)
                return;
            const currentRef = this.refs[currentIndex];
            const nextIndex = XMN.adjacentPostIndex(this.refs, currentRef.statusId, direction, currentIndex);
            if (direction === -1 && nextIndex === null)
                return;
            const generation = this.navGeneration;
            const profile = this.originProfile;
            const initialDestination = nextIndex === null ? null : this.findLiveLink(this.refs[nextIndex]);
            const startingGrid = nextIndex === null && this.originTimeline ? this.captureGrid() : null;
            // An old media-timeline entry may have been evicted from X's virtualized DOM.
            // Do not close the active viewer when the known destination is no longer clickable.
            if (nextIndex !== null && !initialDestination) {
                this.toast('移動先が一覧から消えています。ビューアは閉じません');
                return;
            }
            const closeButton = this.findCloseButton(oldViewer);
            if (!closeButton) {
                this.toast('Xの閉じるボタンが見つからず、移動を中止しました');
                return;
            }
            this.navigationBusy = true;
            this.updateViewerState();
            // Only show a handoff for a previously decoded, owned destination photo.
            // The fallback (no ready photo) is always X's unmodified navigation.
            if (nextIndex !== null)
                this.beginVisualHandoff(this.refs[nextIndex]);
            let destinationOpened = false;
            try {
                closeButton.click();
                if (!await this.waitForViewerToClose(oldViewer)) {
                    this.toast('ビューアを閉じられませんでした');
                    return;
                }
                if (generation !== this.navGeneration || XMN.mediaProfileFromPath(window.location.pathname) !== profile)
                    return;
                // SPA navigation may return to a different Photos/Videos filter than the
                // timeline that supplied these refs. Never open a ref from the wrong grid.
                const returnedTimeline = XMN.mediaTimelineKey(window.location.pathname, window.location.search);
                if (this.originTimeline && returnedTimeline !== this.originTimeline) {
                    // Some X routes drop ?filter=photo on modal close. Accept that
                    // normalization only when the EXACT same observed destination link
                    // remains connected; an explicit switch to video is never accepted.
                    const droppedFilter = returnedTimeline === `${profile}|default` &&
                        this.originTimeline !== `${profile}|default`;
                    const unchangedTarget = initialDestination && nextIndex !== null &&
                        this.findLiveLink(this.refs[nextIndex]) === initialDestination &&
                        initialDestination.isConnected;
                    const retainedGrid = startingGrid !== null && startingGrid.firstTiles.length > 0 &&
                        !this.hasGridTurnedOver(startingGrid);
                    if (!droppedFilter || !(unchangedTarget || retainedGrid)) {
                        this.toast('一覧の種類が切り替わったため、移動を中止しました');
                        return;
                    }
                }
                let destination = nextIndex === null ? null : this.refs[nextIndex];
                // At the end, only click an observed, different post. Never guess a URL.
                if (!destination && direction === 1) {
                    destination = await this.loadNextPost(currentRef.statusId, generation, currentIndex);
                }
                if (generation !== this.navGeneration)
                    return;
                const link = destination && destination.statusId !== currentRef.statusId ? this.findLiveLink(destination) : null;
                if (link) {
                    link.click();
                    destinationOpened = true;
                }
                else {
                    // Don't navigate to a guessed URL or re-open an unrelated status.
                    this.toast('次の項目を見つけられませんでした。一覧で続きを読み込んでください');
                    // Restore current viewer when its source is still present.
                    this.findLiveLink(currentRef)?.click();
                }
            }
            catch (error) {
                console.warn('X Media Navigator navigation cancelled:', error);
                this.toast('メディアの切り替えに失敗しました');
            }
            finally {
                if (!destinationOpened)
                    this.clearVisualHandoff();
                this.navigationBusy = false;
                this.updateViewerState();
            }
        }
    }
    XMN.Controller = Controller;
})(XMN || (XMN = {}));
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new XMN.Controller(), { once: true });
}
else {
    new XMN.Controller();
}
