X Media Navigator v2.4.23 窶・PRIVATE B5 QA candidate (NOT RELEASED)
Verified private Git source: 57aa63957000d6694ba608c2dd4f00bebfa73847
This folder is a NEW side-by-side Chrome unpacked extension candidate.
The stable v2.4.18, QA v2.4.20, B4 QA v2.4.21 and B5 QA v2.4.22 folders have not been changed.

To test manually:
1. Disable ALL older X Media Navigator extensions temporarily.
2. Open chrome://extensions, enable Developer mode, choose Load unpacked,
   and select this new versioned folder.
3. Start with an X account's public Media tab, use left/right arrows,
   and verify multiple-photo posts, GIF/video, and 28 -> 29.
4. Confirm that replies remain correct during native SPA transitions.
   Between separately archived pages, full document navigation is expected.
5. Test disabled network, rapid repeated keys, page refresh and Back/Forward.
6. Check the preview is not painted over X replies or other photos.
7. If any real X behavior differs, do not publish or overwrite stable Chrome.
8. Optional: manually run B5_READONLY_AUDIT.js in Chrome DevTools Snippets
   while the X viewer is open. It reports only aggregate counts/booleans.
   A DOM-visible image is NOT proof of Paint; inspect the screen yourself.

FxEmbed is a third-party service; explicitly approving continuation shares
the public account handle and normal network metadata with that service.
No X cookies or credentials are sent intentionally.
Never share raw HAR, signed-in network logs, cookies or access tokens.
Source evidence: docs/implementation/B5-PROVIDER-INTEGRITY-20261030.md