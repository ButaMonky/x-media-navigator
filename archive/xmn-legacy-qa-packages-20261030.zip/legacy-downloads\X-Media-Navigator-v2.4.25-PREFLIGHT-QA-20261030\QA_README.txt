X Media Navigator v2.4.25 窶・PRIVATE PREFLIGHT QA candidate (NOT RELEASED)
Verified private Git source: 2746b80f7af13fe0010b2f0f0e51577d9e648845
This folder is a NEW side-by-side Chrome unpacked extension candidate.
The stable v2.4.18 and all existing QA versions v2.4.20窶砺2.4.24 have not been changed.

To test manually:
1. Disable ALL older X Media Navigator extensions temporarily.
2. Open chrome://extensions, enable Developer mode, choose Load unpacked,
   and select this new versioned folder.
3. Start with an X account's public Media tab, use left/right arrows,
   and verify multiple-photo posts, GIF/video, and 28 -> 29.
4. Confirm that replies remain correct during native SPA transitions.
   Between separately archived pages, full document navigation is expected.
5. Test disabled network, rapid repeated keys, page refresh and Back/Forward.
6. Check the preview is not painted over X replies or other photos.
7. Test browser Back/Forward after archiving at least 3 checkpoint pages.
   At 64 saved pages, verify no more FxEmbed requests are started.
   Rapid repeated right keys must not generate duplicate public requests.
8. If any real X behavior differs, do not publish or overwrite stable Chrome.
9. Optional: manually run B5_READONLY_AUDIT.js in Chrome DevTools Snippets
   while the X viewer is open. It reports only aggregate counts/booleans.
   A DOM-visible image is NOT proof of Paint; inspect the screen yourself.

FxEmbed is a third-party service; explicitly approving continuation shares
the public account handle and normal network metadata with that service.
No X cookies or credentials are sent intentionally.
Never share raw HAR, signed-in network logs, cookies or access tokens.
Source evidence: docs/implementation/B2-PREFLIGHT-RACE-20261030.md