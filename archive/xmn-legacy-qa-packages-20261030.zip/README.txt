X Media Navigator - 保存・整理記録 (2026-10-30 JST)

Chrome拡張の唯一の更新先:
  %USERPROFILE%\Downloads\X-Media-Navigator-Current
  現在のmanifest: 2.4.26 Consent PRIVATE QA (実際のXでの最終受入は未完了)

このArchiveは保管場所です。Chromeの「パッケージ化されていない拡張機能」には指定しないでください。
  versions\current-v2.4.18-before-v2.4.26-20261030
    旧固定版の6ファイル。削除せず保全。
  legacy-downloads\
    整理前の旧QA版・元フォルダ・ZIP・sha256・QA証拠・旧バックアップ17項目。

v2.4.26の原本ZIPはlegacy-downloadsの中にあります。
  X-Media-Navigator-v2.4.26-CONSENT-QA-20261030.zip
  SHA256: AB3BDB42A23B79A4B2ACDCC9BDE79D7927C10390481D6DD416626396576D93E7
  Current内の10ファイルはこの検証済みQAフォルダからコピーし、全てハッシュ照合済み。

今後の方針:
- Chrome用に増殖するバージョン別QAフォルダは作らず、上記Currentだけを更新。
- 更新前版はこのArchive内でバックアップし、検証完了後のみCurrentを差し替える。
- 過去のUpdate-Chrome-QA.cmdは旧FxEmbed QAフォルダ専用。実行すると別フォルダを再作成するため使わない。
- Documents配下のGit作業フォルダは一部に未コミット差分があり、今回のDownloads整理では触れていない。
- Chromeへの自動導入／ブラウザの再読み込みは行っていない。Chromeの拡張管理からCurrentを指定して再読み込み。
- 実際のXの画面での受入完了までは正式公開・100%完了と扱わない。
