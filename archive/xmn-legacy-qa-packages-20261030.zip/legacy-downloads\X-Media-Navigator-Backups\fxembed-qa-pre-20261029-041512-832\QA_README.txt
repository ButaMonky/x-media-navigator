X Media Navigator FxEmbed QA - v2.4.19 / source 0b3cbce
This is an UNRELEASED test version; official main and stable install are unchanged.
The third-party FxEmbed API receives a public profile handle and normal network metadata after your consent.
HOW TO CHECK IN CHROME:
1. Disable every other X Media Navigator extension (do not remove it).
2. Once: chrome://extensions -> Developer mode -> Load unpacked -> choose THIS folder.
3. Later: run Update-Chrome-QA.cmd in the project root, click Reload on this extension card and refresh the X tab.
4. On X: F12 -> Console -> filter "[XMN"; confirm startup, fxembed.* and preview.* events.
5. A "preview.low_thumbnail_decoded" entry proves preparation; "preview.visible" with quality=low proves actual display.
6. A direct document navigation cannot show the old modal's low-res handoff. It is not proof of an SPA transition.
Do not share private HAR, cookies, tokens, raw network URLs or full browser logs.